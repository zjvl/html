const express = require("express");
const app = express();
const PORT = 11111;


console.log("================================a2a");
//앱 세팅
app.set("views", "./views");
app.set("view engine", "ejs");

const home = require("./src/routers/home");
app.use("/" , home); //use -> 미들웨어를 등록

app.listen( PORT, () => {
    console.log("서버 가동");
});


//module.exports = app;



