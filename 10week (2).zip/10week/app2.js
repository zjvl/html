const { Console } = require('console');
const express = require('express');
const mariadb = require('mariadb');

//const database = require('mariadb');
const config = require('./db/config.js');
//const db = require('mysql');
const morgan = require('morgan');

const app = express();
//app.use(express.static('public'));    
app.use(express.urlencoded({extended:false}));

//로킹
app.use(morgan('combined'));


//html을 나타내는 엔진으로 ejs패키지를 사용
app.set('views', __dirname+'/views');
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);
app.locals.pretty - true; // 코드 이쁘게 해줌
//__filename 은 현재 실행 중인 파일 경로
//__dirname 은 현재 실행 중인 폴더 경로


//pool



app.get('', (request, response)=>{
    response.render('index.html', {ok:"로그인 하세요!"});
});
app.get('/login', (request, response)=>{
    //response.sendFile(__dirname+'/login.html');
    response.render('login.html');
});



// app.post('/login', async (request, response)=>{
//     const id = request.body.user_id;
//     const pw = request.body.user_pw;
//     let conn;
//     try{
//         conn = await pool.getConnection();
//         let str = `select * from users where userid="${id}" and userpw=password("${pw}");`;
//         //console.log(str);
//         const rows = await conn.query(str);
//         //console.log(rows);
//         if(rows == 0){
//             console.log('로그인실패');
//             response.render('index.html', {ok:"다시 로그인하세요"});
//         }else{
//             console.log('로그인성공');
//             let userid = rows[0].userid;
//             response.render('index.html', {ok:`${userid}님`});
//         }
//     }catch(e){
//         throw e;
//     }finally{
//         if(conn)    return conn.release();
//     }
// });
app.post('/login', async (request, response)=>{
    const id = request.body.user_id;
    const pw = request.body.user_pw;
    
    let conn;
    try {
        conn = await pool.getConnection();
        const result = await conn.query(`select * from users where userid="${id}" and userpw=password("${pw}");`);
        console.log(result);
        const rows = await conn.query(str);
        console.log(rows);
        res.send({
          status: 200,
          data: result
        });
      } catch (err) {
        throw err;
      } finally {
        if (conn) {
          //conn.end();
          conn.release();
          console.log('------connection release');
          console.log('------totalConnections', pool.totalConnections());
          console.log('------activeConnections', pool.activeConnections());
          console.log('------idleConnections', pool.idleConnections());
        }
    
      }
    
    })
    origin: dhirajaknurwar/node-expressjs-mariadb
    controllers/o
  


app.listen(55555, ()=>{
    console.log('서버 실행중...');
});