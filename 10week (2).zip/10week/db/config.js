"use strict"

const db = require('mysql');

const pool = db.createPool({
    host : 'localhost',
    port : 3307,
    user : 'nodejs_admin',
    password : '1234',
    database : 'nodejs_test',
    connectionLimit : 10
});

module.exports = mysql.createPool(connection);