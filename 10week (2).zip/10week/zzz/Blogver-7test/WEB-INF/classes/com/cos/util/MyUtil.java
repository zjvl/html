package com.cos.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;


public class MyUtil {
	private static String naming = "MyUtil : ";
	public static String getMyCookie(HttpServletRequest request) {
		String cookieID = null;

		Cookie[] cookies = request.getCookies();

		for (Cookie c : cookies) {
			if (c.getName().equals("cookieID")) {
				// 엘레멘트 찾아서 넣어주면 됨.
				cookieID = c.getValue();
			}
		}
		System.out.println(naming+cookieID);
		return cookieID;
	}
	
	public static String getReplace(String code) {	
		return code.replaceAll(" ", "&nbsp;").replaceAll("<", "&lt").replaceAll(">", "&gt").replaceAll("\n", "<br>");
	}

	public static String StringSort(String result){
		String resultt1 ="";
		String resultt2 ="";
		
		if(result.length() > 43) {
			resultt1 = result.substring(0, 38);
			if(result.length() > 77)
			{
				resultt2 = result.substring(39, 77);
			}else {
				resultt2 = result.substring(39, result.length());
			}
			
		}else {
			return result.substring(0, result.length());
		}
		return result = resultt1 +"<br />" +resultt2 +"..."; 	 
		
	}
	

	public static String youtubeparse(String content) {
		//이걸 유트브할떄 'v='으로 파싱하고 & 로 파싱한다
		//왜냐하면 v=는 뒤에 있을수 있다 
		//그래서 &파싱을 뒤에 한다 앞에하면 v=  index번지가 달라진다.
		
		//https://www.youtube.com/watch?v=G94jQi0UGr0
		String result = null;
		result = content;
		if(content.contains("www.youtube.com/")) {
			
				String youtube = content;
				String original = content;		
				String[] youtube2 = youtube.split("v=");
				String youtube3 = youtube2[0];
				String youtube4 = youtube2[1];
				String youtubetest = youtube3+youtube4;
				String iFrame = "";
				if(youtubetest.contains("<br")) {
					return content;
				}else {
					iFrame = "<iframe id=\"player\" type=\"text/html\" width=\"680\" height=\"390\" src=\"http://www.youtube.com/embed/"+youtube4+"\" frameborder=\"0\" webkitallowfullscreen=\"\" mozallowfullscreen=\"\" allowfullscreen=\"\"></iframe>";
					return original+"<br />"+iFrame ;
				}
						
		}
		return result;
		
		
		
		
	}
	
	
	public static String preview(String content){
		String result = "";
		
		//p태그
		String p_value = "";
		int p_length = 0;
		int p_index = 0;
		boolean p_vacant = true;
		
		//img태그
		boolean img_vacant = true;
		
		//공백체크(아무글도 적지 않으면 <br>만 생겨 있다.)
		boolean br_vacant = true;
		
		//태그 없이 글만 있는 것 체크
		boolean notag_vacant = true;
		
		Document doc = Jsoup.parse(content);
		Elements img_tag = doc.select("img");
		Elements p_tag = doc.select("p");	
		Elements br_tag = doc.select("br");
		//System.out.println(img_tag);
		//System.out.println(p_tag);
		//System.out.println(br_tag);
		
/*		for(Element e : p_tag){
			p_count++;
		}*/
		
		for(int i=0; i<p_tag.size(); i++){
			p_value = doc.select("p").eq(i).text();
			if(p_length < p_value.length()){
				p_length = p_value.length();
				if(!p_value.equals("")){
					p_index = i;
					p_vacant = false;
				}
			}
		}
		
		if(img_tag.size() > 0){
			img_vacant = false;
		}
		
		if(br_tag.size() > 0){
			br_vacant = false;
		}
		
		if(content.length() > 0){
			notag_vacant = false;
		}
		
		if(p_vacant == false){
			result = doc.select("p").eq(p_index).text();
		}else if(img_vacant == false){
			return result = "본문에 이미지만 존재합니다.";
		}else if(br_vacant == false){
			return result = "본문에 내용이 존재하지 않습니다.";
		}else if(notag_vacant == false){
			result = content;
		}else{
			return result = "본문에 내용이 존재하지 않습니다.";
		}
		
		
		
		System.out.println(naming+result);
		if (result.contains("www.youtube.com/")) {
			return result = youtubeparse(result);
			 
		}else {
			return result = StringSort(result);
		}
	}

}
