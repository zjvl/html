package com.cos.controller.member;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cos.action.Action;
import com.cos.dao.MemberDAO;
import com.cos.dto.MemberVO;
import com.cos.util.SHA256;
import com.cos.util.Script;

public class JoinAction implements Action{
	private static String naming = "JoinAction : ";
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "board?cmd=board_list";
		System.out.println(1);
		MemberVO member = new MemberVO();
		System.out.println(2);
		member.setId(request.getParameter("id"));
		member.setPassword(request.getParameter("password"));
		System.out.println(3);
		String testpw = SHA256.getSHA256((request.getParameter("password")));
		System.out.println(4);
		member.setUsername(request.getParameter("username"));
		member.setEmail(request.getParameter("email"));
		System.out.println(5);
		MemberDAO dao = new MemberDAO();
		System.out.println(1);
		int result = dao.insert(member);
		System.out.println(6);
		if(result == 1){
			HttpSession session = request.getSession();
			session.setAttribute("id", member.getId());
			Script.moving(response, "회원가입 성공", url);
		}else if(result == -1){
			System.out.println(naming+"sql error");
			Script.moving(response, "database 에러");
		}
	}
}
