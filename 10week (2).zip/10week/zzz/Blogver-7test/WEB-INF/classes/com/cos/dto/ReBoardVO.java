package com.cos.dto;

public class ReBoardVO {
	private String username;
	private String recontent;
	private String wirtedate;
	private int num;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRecontent() {
		return recontent;
	}
	public void setRecontent(String recontent) {
		this.recontent = recontent;
	}
	public String getWirtedate() {
		return wirtedate;
	}
	public void setWirtedate(String wirtedate) {
		this.wirtedate = wirtedate;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
}
