package com.cos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cos.dto.BoardVO;
import com.cos.dto.HotPostDTO;
import com.cos.util.DBManager;

public class BoardDAO {
	
	private PreparedStatement pstmt;
	private ResultSet rs;

	// insert
	public int insert(BoardVO board) {
		String SQL = "INSERT INTO board(title,content,writedate, id , readcount) VALUES(?,?,now(),?, 0 )";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getContent());
			pstmt.setString(3, board.getId());
			pstmt.executeUpdate();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
		return -1;
	}
	public int delete2(String num) {
		String SQL = "delete from board where num = ?";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			
			pstmt.setString(1,  num);
			pstmt.executeUpdate();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
		return -1;
		
	}
	public int delete(int num) {

		 StringBuilder sb = new StringBuilder();
		 Statement stmt = null; 
		 String sql = sb.append("delete from board num =" )
	                .append("'" + num + "'")
	                .append(";")
	                .toString();
	        try {
	            stmt.executeUpdate(sql);
	            return 1;
	        } catch (SQLException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }

	        return -1;
	
		
	}
	
	
	public int readcountplus(int num_readcount) {
		String SQL = "update board set readcount = readcount+1 Where num = ?;";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, num_readcount);
			pstmt.executeUpdate();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
		return -1;
	}
	public int update(BoardVO board) {
		//UPDATE userTbl SET Money = 10000 , item1 = '티셔츠'


		String SQL = "update board set title = ?, content = ? Where num = ?;";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, board.getTitle());
			pstmt.setString(2, board.getContent());
			pstmt.setInt(3, board.getNum());
			System.out.println("안녕하세요 업데이트입니다,.");
			pstmt.executeUpdate();
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt);
		}
		return -1;
	}
	
	
	// select
	public BoardVO select(int num) {
		String SQL = "SELECT * FROM board where num = ?";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				BoardVO board = new BoardVO();
				board.setId(rs.getString("id"));
				board.setNum(rs.getInt("num"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setWritedate(rs.getString("writedate"));
				board.setReadcount(rs.getInt("readcount"));
				return board;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
			readcountplus(num);
		}
		return null;
	}
	public BoardVO updateselect(int num) {
		String SQL = "SELECT * FROM board where num = ?";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				BoardVO board = new BoardVO();
				board.setId(rs.getString("id"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setWritedate(rs.getString("writedate"));
				board.setReadcount(rs.getInt("readcount"));
				return board;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
			
		}
		return null;
	}
	
	//readcount 젤 많은거 
	//-103 ==  글이 없으면 그냥 표시
	public int hotposttest( ) {
		String SQL = "select count(title) from board order by readCount DESC limit 4";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			if(rs.next() ){
				Integer test = 0;
				
				test = (Integer)rs.getInt(1);
				
				if(test==4) {
					return -200;
				}else {
					return -400;
				}
			}		
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return -400;
	}
	
	
	
	
	public List<HotPostDTO> readcount_hotpost( ) {
		String SQL = "select title, num from board order by readCount DESC limit 3";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();
			List<HotPostDTO> hotPostDTOs = new ArrayList<>();
			while(rs.next()){
				HotPostDTO hotDTO = new HotPostDTO();
				String test = "";
				//int testnum = 0;
				hotDTO.setTitle(rs.getString("title"));
				hotDTO.setNum(rs.getInt("num"));
				//testnum = rs.getInt(2);
				System.out.println(hotDTO.getTitle());
				hotPostDTOs.add(hotDTO);
							
			}
			return hotPostDTOs;	
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return null;
	}
	//-103 ==  글이 없으면 그냥 표시
		public String readcount_hotpost2( ) {
			String SQL = "select title from board order by readCount DESC limit 1, 1";
			Connection conn = DBManager.getConnection();
			try {
				pstmt = conn.prepareStatement(SQL);
				rs = pstmt.executeQuery();
				if(rs.next() ){
					String test = "";
					test = rs.getString(1);
						return test;			
				}		
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt, rs);
			}
			return null;
		}
		//-103 ==  글이 없으면 그냥 표시
		public String readcount_hotpost3( ) {
			String SQL = "select title from board order by readCount DESC limit 2, 1";
			Connection conn = DBManager.getConnection();
			try {
				pstmt = conn.prepareStatement(SQL);
				rs = pstmt.executeQuery();
				if(rs.next() ){
					String test = "";
					test = rs.getString(1);
						return test;			
				}		
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				DBManager.close(conn, pstmt, rs);
			}
			return null;
		}
	
	
	
	
	
	// select_all
	public ArrayList<BoardVO> select_all() {
		String SQL = "SELECT * FROM board order by num desc";
		Connection conn = DBManager.getConnection();
		try {
			pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();

			ArrayList<BoardVO> arr = new ArrayList<>();
			while (rs.next()) {
				BoardVO board = new BoardVO();
				board.setNum(rs.getInt("num"));
				board.setId(rs.getString("id"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setWritedate(rs.getString("writedate"));
				board.setReadcount(rs.getInt("readcount"));
				arr.add(board);
			}
			return arr;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return null;
	}
	//Search
	public List<BoardVO> Searchboard(String search) {
		String SQL = "select * from board where title like ?" ;
		Connection conn = DBManager.getConnection();
		try {
			
			
			
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, "%" + search + "%");
			rs = pstmt.executeQuery();
			
			List<BoardVO> arr = new ArrayList<BoardVO>();
			while (rs.next()) {
				BoardVO board = new BoardVO();
				board.setNum(rs.getInt("num"));
				board.setId(rs.getString("id"));
				board.setTitle(rs.getString("title"));
				board.setContent(rs.getString("content"));
				board.setWritedate(rs.getString("writedate"));
				arr.add(board);
			}
			return arr;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			DBManager.close(conn, pstmt, rs);
		}
		return null;
	}
	
}
