const path = require('db/config.js');

console.log(path.dirname(__filename));