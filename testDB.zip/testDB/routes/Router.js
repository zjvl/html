const Ctrl = require("../controllers/Ctrl")
const router = require("express").Router();


router.route('/')
    .get(Ctrl.get)
    .post(Ctrl.insert);

module.exports = router;