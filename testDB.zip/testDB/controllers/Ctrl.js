const connection = require('../dbConfig');

const Ctrl = {
    get : async  (req, res) =>{
        connection.query('select * from users',(error, rows) => {
            if(error) throw error;
            response.render('index.html', {ok:"로그인 하세요!"});
        })
    },
    insert : async  (req, res) =>{
        //자바 스크립트 구조분해할당
        const {id,title,userid,userpw } = req.body;
        const sql = `insert into users(id,userid,userpw)
        values(${id},${userid},${userpw});`

        connection.query(
            sql,(error,rows) => {
                if(error) throw error;
                res.send(rows);
            }
        )
    }
}

module.exports = Ctrl;